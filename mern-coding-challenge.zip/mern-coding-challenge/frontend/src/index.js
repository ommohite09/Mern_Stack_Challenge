

import React from 'react';
import ReactDOM from 'react-dom';
import './index.css'; // Optional, for styling
import App from './app.js';
import reportWebVitals from './reportWebVitals'; // Optional for performance measurements

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

// Optional: for measuring performance (you can remove this part if not needed)
reportWebVitals();
