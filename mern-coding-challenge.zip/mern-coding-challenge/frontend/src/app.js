import React, { useState } from 'react';
import PieChart from './components/PieChart';

function App() {
  const [month, setMonth] = useState('March');  // Example month, you can update this based on user input

  return (
    <div className="App">
      <h1>MERN Stack Application</h1>
      <PieChart month={month} />  {/* Pass the month to PieChart */}
      {/* You can add more components here like TransactionsTable, Statistics, etc. */}
    </div>
  );
}

export default App;
