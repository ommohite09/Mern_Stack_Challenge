import React, { useEffect, useState } from 'react';
import { fetchCategories } from '../api';  // Import the fetchCategories function from api.js

const PieChart = ({ month }) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const getCategories = async () => {
      try {
        const result = await fetchCategories(month);  // Fetch categories for the specified month
        setData(result);
      } catch (error) {
        console.error("Error fetching categories for pie chart:", error);
      }
    };

    if (month) {  // Ensure month is defined before fetching
      getCategories();
    }
  }, [month]);  // Run the effect whenever month changes

  return (
    <div>
      {/* Render your pie chart using the `data` here */}
      {/* Example: <Pie data={data} /> */}
      <h2>Categories for {month}</h2>
      {/* Here, you can implement your Pie Chart rendering logic using a library like react-chartjs-2 */}
    </div>
  );
};

export default PieChart;
