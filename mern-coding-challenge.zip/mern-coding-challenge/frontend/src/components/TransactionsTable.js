
import React, { useEffect, useState } from 'react';
import { fetchTransactions } from '../app'; 

const TransactionsTable = () => {
  const [transactions, setTransactions] = useState([]); 

  useEffect(() => {
    const getTransactions = async () => {
      const data = await fetchTransactions(); 
      setTransactions(data); 
    };
    getTransactions(); 
  }, []);

  return (
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Title</th>
          <th>Description</th>
          <th>Price</th>
          <th>Date of Sale</th>
          <th>Sold</th>
          <th>Category</th>
        </tr>
      </thead>
      <tbody>
        {transactions.map((tx) => (
          <tr key={tx.id}>
            <td>{tx.id}</td>
            <td>{tx.title}</td>
            <td>{tx.description}</td>
            <td>{tx.price}</td>
            <td>{new Date(tx.dateOfSale).toLocaleDateString()}</td>
            <td>{tx.sold ? 'Yes' : 'No'}</td>
            <td>{tx.category}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default TransactionsTable;
