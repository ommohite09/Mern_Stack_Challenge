import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import { fetchPriceRanges } from '../app';

const BarChart = ({ month }) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const getPriceRanges = async () => {
      const result = await fetchPriceRanges(month);
      setData(result);
    };
    getPriceRanges();
  }, [month]);

  const chartData = {
    labels: data.map((item) => `$${item._id}`),
    datasets: [
      {
        label: 'Number of Transactions',
        data: data.map((item) => item.count),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
    ],
  };

  return <Bar data={chartData} />;
};

export default BarChart;
