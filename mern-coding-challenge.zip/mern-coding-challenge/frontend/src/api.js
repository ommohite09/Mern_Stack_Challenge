import axios from 'axios';

// Base URL for the backend server
const API_BASE_URL = 'http://localhost:5000/api';  // Ensure this matches your backend server URL

// Function to fetch transactions
export const fetchTransactions = async (params) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/transactions`, { params });
    return response.data;
  } catch (error) {
    console.error("Error fetching transactions:", error);
    throw error;
  }
};

// Function to fetch category distribution for the Pie Chart
export const fetchCategories = async (month) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/categories`, {
      params: { month }
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching categories:", error);
    throw error;
  }
};

// Function to fetch price range data for the Bar Chart
export const fetchPriceRanges = async (month) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/price-range`, {
      params: { month }
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching price ranges:", error);
    throw error;
  }
};

// Function to fetch statistics (total sales, items sold, etc.)
export const fetchStatistics = async (month) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/statistics`, {
      params: { month }
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching statistics:", error);
    throw error;
  }
};
